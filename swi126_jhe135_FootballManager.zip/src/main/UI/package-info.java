/**
 * This package contains all the classes that are used to create the user interface.
 */
package main.UI;