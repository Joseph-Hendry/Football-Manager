/**
 * This package contains the main class of the application.
 */
package main;