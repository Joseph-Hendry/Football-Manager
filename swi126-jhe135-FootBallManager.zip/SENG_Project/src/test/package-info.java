/**
 * Contains the tests.
 */
package test;